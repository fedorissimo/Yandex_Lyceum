from flask import Flask, render_template
import json
from random import randrange
app = Flask(__name__)


@app.route('/member')
def login():
    with open('templates\crewmates.json', encoding='UTF-8') as file:
        data = json.load(file)
        inf = randrange(len(data))
        crewmate = data[inf]
        crewmate['list'] = ', '.join(sorted(crewmate['list']))
    return render_template('table.html', data=crewmate)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
