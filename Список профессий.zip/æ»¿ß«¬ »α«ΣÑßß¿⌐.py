from flask import Flask, render_template
app = Flask(__name__)


@app.route('/list_prof/<value>')
def list_prof(value):
    profs = ['Предатель', 'Член экипажа', 'Ученый', 'Инженер']
    return render_template('profs.html', array_prof=profs, value=value)


if __name__ == "__main__":
    app.run(port=8080, host='127.0.0.1')