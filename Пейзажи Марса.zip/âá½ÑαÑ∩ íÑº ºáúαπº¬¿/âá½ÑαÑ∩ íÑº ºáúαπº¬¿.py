from flask import Flask, render_template, request
import os
app = Flask(__name__)


@app.route('/galery', methods=['POST', 'GET'])
def login():
    global photo_list, count
    if request.method == 'GET':
        return render_template('galery.html', photo_list=photo_list)
    elif request.method == 'POST':
        count += 1
        name = f'web{count}.jpg'
        file = request.files['file']
        with open(name, 'wb') as img:
            img.write(file.read())
            img.close()
        photo_list.append(name)
        return render_template('galery.html', photo_list=photo_list)


if __name__ == '__main__':
    os.chdir('static/img')
    photo_list = os.listdir()
    count = len(photo_list)
    app.run(port=8080, host='127.0.0.1')
